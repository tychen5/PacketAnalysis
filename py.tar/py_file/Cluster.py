#!/usr/bin/env python
# coding: utf-8

# In[1]:


class Cluster:
    def __init__(self, clusterID, clusterPayload):
        self.id = clusterID
        self.clusterPayload = clusterPayload

